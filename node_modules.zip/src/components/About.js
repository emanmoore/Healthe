import React from 'react'

const About = () => {
  return (
    <div>
        <h4>About healthy habits</h4>
      
    </div>
  )
}

export default About
