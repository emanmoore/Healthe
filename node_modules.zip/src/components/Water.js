import React from 'react'

const Water = () => {
  return (
    <div>
      <h2>This is the water page</h2>
    </div>
  )
}

export default Water
