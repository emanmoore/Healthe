import React from 'react'

const Contact = () => {
  return (
    <div>
      <h3>Contact section located here</h3>
    </div>
  )
}

export default Contact
