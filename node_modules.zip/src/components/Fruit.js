import React from 'react'

function Fruit() {
  return (
    <div>
      <h1>fruit page</h1>
      
    </div>
  )
}

export default Fruit
