import React from 'react'

function Home() {
  return (
    <div>
      <h2>Homes page</h2>
      
    </div>
  )
}

export default Home
