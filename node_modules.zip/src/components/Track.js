import React from 'react'

const  Track = () => {
  return (
    <div>
      <h3>How much have you consume</h3>
    </div>
  )
}

export default Track
